package Presentation;

public class NotificationUpdate implements Runnable {
    Thread thread;

    public NotificationUpdate() {
    }


    @Override
    public void run() {

    }
}

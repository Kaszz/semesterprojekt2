package Domain;

public enum CreditType {
        Instruktør,
        Producer,
        Producent,
        Hovedrolle,
        Birolle,
        Fotograf,
        Scenografi,
        Klipper;
}

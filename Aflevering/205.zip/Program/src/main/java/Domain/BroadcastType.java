package Domain;

public enum BroadcastType {

    SERIE,
    FILM,
    LIVE
}

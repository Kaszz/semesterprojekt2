package Interfaces;

public interface IConnectionDB {
    public static void connect() {};
}

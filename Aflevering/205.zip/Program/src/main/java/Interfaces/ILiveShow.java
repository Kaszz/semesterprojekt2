package Interfaces;

public interface ILiveShow extends IBroadcast{
    public String getLocation();
}

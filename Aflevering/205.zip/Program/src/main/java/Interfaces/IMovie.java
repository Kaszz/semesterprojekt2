package Interfaces;

public interface IMovie extends IBroadcast {
}

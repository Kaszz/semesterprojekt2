package Interfaces;

public interface IUser extends IAccount {
    public int getUserID();
    public boolean getEnabled();
}

package Interfaces;

public interface IEpisode extends IBroadcast {
    public String getShowName();
    public int getSeason();
    public int getEpisodeNum();
}
